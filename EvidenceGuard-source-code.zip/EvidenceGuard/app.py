
import streamlit as st
import pandas as pd

from modules.ingestion import load_uploaded_files, validate_evidence
from modules.api_finance import detect_api_finance_alerts
from modules.correlation import (
    build_correlations,
    build_timeline,
    detect_network_alerts,
)
from modules.dashboard import render_dashboard


st.set_page_config(
    page_title="EvidenceGuard",
    page_icon="🛡️",
    layout="wide",
)

st.title("🛡️ EvidenceGuard")
st.caption("Evidence-led security investigation | Human review required")

st.info(
    "Upload supplied case evidence. Demo records are synthetic "
    "and must never be presented as actual case findings."
)

uploaded = st.file_uploader(
    "Upload evidence files (CSV, JSON, XLSX, XLS, PDF or DOCX)",
    type=["csv", "json", "xlsx", "xls", "pdf", "docx"],
    accept_multiple_files=True,
)

if uploaded:
    try:
        evidence = load_uploaded_files(uploaded)

        with st.expander("Ingestion validation", expanded=True):
            for note in validate_evidence(evidence):
                st.write(f"• {note}")

        st.caption(
            "Document files are ingested as extracted text by page/paragraph. "
            "Scanned PDFs may require OCR and are not guaranteed to yield searchable text."
        )

        # Run both detection modules
        api_alerts = detect_api_finance_alerts(evidence)
        network_alerts = detect_network_alerts(evidence)

        # Combine API/finance and network alerts
        alerts = pd.concat(
            [api_alerts, network_alerts],
            ignore_index=True,
        )

        # Build correlations and event timeline
        correlations = build_correlations(evidence)
        timeline = build_timeline(evidence)

        # Display dashboard
        render_dashboard(
            evidence,
            alerts,
            correlations,
            timeline,
        )

        # Download combined alerts
        st.download_button(
            "Download alerts as CSV",
            data=alerts.to_csv(index=False).encode("utf-8"),
            file_name="evidenceguard_alerts.csv",
            mime="text/csv",
        )

    except Exception as exc:
        st.error(f"Could not process the uploaded evidence: {exc}")
        st.exception(exc)

else:
    st.markdown("### Getting started")

    st.write("1. Upload one or more original evidence files.")
    st.write("2. Review the normalised records and source references.")
    st.write("3. Examine alerts, correlations and the event timeline.")
    st.write("4. Download the alert results for the investigation proof pack.")

    st.caption(
        "Processing happens locally in this Streamlit session. "
        "Original files are read, not edited."
    )
