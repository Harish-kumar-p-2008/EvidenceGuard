import pandas as pd
from modules.api_finance import detect_api_finance_alerts
from modules.correlation import build_correlations

def test_bank_change_without_approval_is_flagged():
    df = pd.DataFrame([{
        "method": "PATCH", "endpoint": "/v2/vendors/V-1/bank-details",
        "approval_ref": None, "evidence_id": "E-1", "row_ref": "file.csv:1"
    }])
    alerts = detect_api_finance_alerts(df)
    assert len(alerts) == 1
    assert alerts.iloc[0]["severity"] == "High"

def test_shared_request_id_is_correlated():
    df = pd.DataFrame([
        {"request_id": "req-1", "row_ref": "a:1"},
        {"request_id": "req-1", "row_ref": "b:1"},
    ])
    result = build_correlations(df)
    assert not result.empty
    assert result.iloc[0]["record_count"] == 2
