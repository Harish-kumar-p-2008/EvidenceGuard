"""EvidenceGuard evidence ingestion and normalisation.

Supports CSV, JSON, XLSX/XLS, PDF and DOCX. Original files are read only.
Each output row keeps its source filename, evidence ID (when present in the
filename), source sheet/page and a stable within-file row reference.
"""
from __future__ import annotations

import json
import re
from io import BytesIO
from pathlib import Path
from typing import Iterable

import pandas as pd

ALIASES = {
    # Timestamp fields in the CRIMEATHON evidence pack
    "ts_utc": "timestamp", "ts_local": "timestamp", "epoch_s": "timestamp",
    "time": "timestamp", "event_time": "timestamp", "datetime": "timestamp",
    # Network/API fields
    "src_ip": "source_ip", "caller_ip": "source_ip", "client_ip": "source_ip",
    "remote_ip": "source_ip", "dst_ip": "destination_ip", "server_ip": "destination_ip",
    "api_key_id": "api_key", "api_credential": "api_key", "credential_id": "api_key",
    "key_id": "api_key", "requestid": "request_id", "req_id": "request_id",
    "vendor": "vendor_id", "vendor_code": "vendor_id", "http_method": "method",
    "uri": "endpoint", "path": "endpoint", "approval_reference": "approval_ref",
    "approval_id": "approval_ref", "evidence": "evidence_id",
    "evidence_reference": "evidence_id",
}

SUPPORTED_EXTENSIONS = {".csv", ".json", ".xlsx", ".xls", ".pdf", ".docx"}


def normalise_column_name(name: object) -> str:
    name = str(name).strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name).strip("_")
    return ALIASES.get(name, name)


def evidence_id_from_filename(filename: str) -> str | None:
    match = re.search(r"(?:^|[^A-Za-z0-9])(E\d{2})(?:[^A-Za-z0-9]|$)", Path(filename).name, flags=re.IGNORECASE)
    return match.group(1).upper() if match else None


def _read_bytes(upload) -> tuple[str, bytes]:
    filename = getattr(upload, "name", None) or getattr(upload, "filename", None) or "uploaded_file"
    raw = upload.getvalue() if hasattr(upload, "getvalue") else upload.read()
    return str(filename), raw


def _normalise_frame(df: pd.DataFrame, filename: str, source_part: str = "") -> pd.DataFrame:
    df = df.copy()
    df.columns = [normalise_column_name(c) for c in df.columns]
    df["source_file"] = filename
    df["source_type"] = Path(filename).suffix.lower().lstrip(".")
    df["source_part"] = source_part
    inferred_id = evidence_id_from_filename(filename)
    if "evidence_id" not in df.columns:
        df["evidence_id"] = inferred_id
    else:
        df["evidence_id"] = df["evidence_id"].where(df["evidence_id"].notna(), inferred_id)
    if "timestamp" in df.columns:
        # E05 uses Unix seconds; other case logs use ISO-like UTC/local strings.
        if Path(filename).name.lower().startswith("e05_") and pd.api.types.is_numeric_dtype(df["timestamp"]):
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", errors="coerce", utc=True)
        else:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    return df


def _parse_csv(filename: str, raw: bytes) -> list[pd.DataFrame]:
    df = pd.read_csv(BytesIO(raw))
    return [_normalise_frame(df, filename)]


def _parse_json(filename: str, raw: bytes) -> list[pd.DataFrame]:
    payload = json.loads(raw.decode("utf-8-sig"))
    # Preserve useful nested collections as records, rather than flattening a
    # wrapper object into a single opaque row (e.g. E04.integrations, E13.messages).
    if isinstance(payload, dict):
        candidate = next((v for v in payload.values() if isinstance(v, list) and v and all(isinstance(x, dict) for x in v)), None)
        records = candidate if candidate is not None else [payload]
    elif isinstance(payload, list):
        records = payload
    else:
        records = [{"value": payload}]
    return [_normalise_frame(pd.json_normalize(records), filename)]


def _parse_excel(filename: str, raw: bytes) -> list[pd.DataFrame]:
    sheets = pd.read_excel(BytesIO(raw), sheet_name=None)
    return [_normalise_frame(frame, filename, source_part=f"sheet:{sheet}") for sheet, frame in sheets.items()]


def _parse_pdf(filename: str, raw: bytes) -> list[pd.DataFrame]:
    from pypdf import PdfReader
    reader = PdfReader(BytesIO(raw))
    rows = [{"page_number": i + 1, "document_text": page.extract_text() or ""} for i, page in enumerate(reader.pages)]
    return [_normalise_frame(pd.DataFrame(rows), filename, source_part="pdf_page")]


def _parse_docx(filename: str, raw: bytes) -> list[pd.DataFrame]:
    from docx import Document
    doc = Document(BytesIO(raw))
    rows = [{"paragraph_number": i + 1, "document_text": p.text} for i, p in enumerate(doc.paragraphs) if p.text.strip()]
    for ti, table in enumerate(doc.tables, start=1):
        for ri, row in enumerate(table.rows, start=1):
            rows.append({"table_number": ti, "row_number": ri, "document_text": " | ".join(c.text for c in row.cells)})
    if not rows:
        rows = [{"document_text": ""}]
    return [_normalise_frame(pd.DataFrame(rows), filename, source_part="docx_content")]


def parse_evidence_file(upload) -> pd.DataFrame:
    """Parse one uploaded file into a normalised DataFrame."""
    filename, raw = _read_bytes(upload)
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {filename}. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")
    parsers = {".csv": _parse_csv, ".json": _parse_json, ".xlsx": _parse_excel,
               ".xls": _parse_excel, ".pdf": _parse_pdf, ".docx": _parse_docx}
    frames = parsers[ext](filename, raw)
    if not frames:
        return pd.DataFrame()
    result = pd.concat(frames, ignore_index=True, sort=False)
    result["row_ref"] = [f"{filename}:{part or 'record'}:{i + 1}" for i, part in enumerate(result["source_part"].fillna(""))]
    return result


def load_uploaded_files(uploads: Iterable) -> pd.DataFrame:
    """Read multiple CSV/JSON/Excel/PDF/DOCX uploads into one DataFrame."""
    frames = [parse_evidence_file(upload) for upload in uploads]
    frames = [frame for frame in frames if not frame.empty]
    return pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()


def validate_evidence(df: pd.DataFrame) -> list[str]:
    """Return validation notes without dropping or modifying source records."""
    findings: list[str] = []
    if df.empty:
        findings.append("No records were loaded.")
    if "timestamp" not in df.columns:
        findings.append("No timestamp column was recognised; this can be normal for reference documents.")
    elif df["timestamp"].isna().any():
        findings.append("Some timestamps are missing or could not be parsed.")
    if "evidence_id" not in df.columns or df["evidence_id"].isna().all():
        findings.append("No evidence ID was found in the filename or record; source_file and row_ref remain available.")
    if "source_file" in df.columns:
        findings.append(f"Loaded {df['source_file'].nunique()} source file(s). Original files were not changed.")
    return findings
