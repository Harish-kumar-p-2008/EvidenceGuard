
"""Kalpesh: explainable API and financial threat detection rules."""

import pandas as pd

SENSITIVE_TERMS = (
    "bank",
    "payment",
    "vendor",
    "iban",
    "swift",
    "account",
    "export",
)


def detect_api_finance_alerts(df):
    """Return review alerts. Rules are heuristic and do not prove malicious activity."""

    alerts = []

    if df.empty:
        return pd.DataFrame(columns=[
            "timestamp",
            "severity",
            "alert_type",
            "reason",
            "evidence_id",
            "row_ref",
            "source_ip",
            "request_id",
            "vendor_id",
        ])

    for _, row in df.iterrows():

        method = str(row.get("method", "")).upper()
        endpoint = str(row.get("endpoint", "")).lower()
        action = str(row.get("action", "")).lower()

        field = str(row.get("field", "")).lower()
        channel = str(row.get("channel", "")).lower()
        changed_by = str(row.get("changed_by", "")).lower()

        event_text = " ".join([
            endpoint,
            action,
            str(row.get("event_type", "")).lower(),
            field,
            channel,
            changed_by,
        ])

        approval = row.get("approval_ref")

        has_approval = (
            pd.notna(approval)
            and str(approval).strip().lower()
            not in ("", "nan", "none", "null")
        )

        alert_type = None
        severity = None
        reason = None

        # Detect changes to bank-related fields.
        bank_field_change = (
            "bank" in field
            and str(row.get("old_value", "")).strip()
            != str(row.get("new_value", "")).strip()
        )

        # Detect bank changes through API write operations.
        bank_change = (
            bank_field_change
            or (
                ("bank" in event_text or "bank-details" in endpoint)
                and (
                    method in ("PATCH", "PUT", "POST")
                    or any(
                        term in action
                        for term in ("change", "update", "modify")
                    )
                )
            )
        )

        if bank_change and not has_approval:

            alert_type = "Bank-detail change missing approval reference"
            severity = "High"
            reason = (
                "A bank-detail write/change event is present, "
                "but no approval reference was found in this record."
            )

        elif any(term in event_text for term in SENSITIVE_TERMS):

            alert_type = "Sensitive API or finance activity"
            severity = "Medium"
            reason = (
                "The record references a sensitive finance, vendor, "
                "payment or export operation; verify authorisation "
                "and business purpose."
            )

        if alert_type:
            alerts.append({
                "timestamp": row.get("timestamp"),
                "severity": severity,
                "alert_type": alert_type,
                "reason": reason,
                "evidence_id": row.get("evidence_id"),
                "row_ref": row.get("row_ref"),
                "source_ip": row.get("source_ip"),
                "request_id": row.get("request_id"),
                "vendor_id": row.get("vendor_id"),
            })

    return pd.DataFrame(alerts)
