"""Sanjay: correlate evidence, detect network anomalies and build a timeline."""

import pandas as pd

LINK_FIELDS = ["request_id", "source_ip", "api_key", "vendor_id"]

# Case-specific review thresholds. These are investigation rules, not proof
# of malicious activity.
SUSPICIOUS_HOST_IP = "10.20.4.77"
SUSPICIOUS_HOST_LABEL = "tb-build-02"
SENSITIVE_DESTINATIONS = ("ledgerone", "helpdeskr")
NORMAL_SYNC_START_HOUR = 1
NORMAL_SYNC_END_HOUR = 3
LARGE_TRANSFER_BYTES = 1_000_000


def build_correlations(df):
    """Summarise records sharing a non-empty correlation identifier."""
    columns = ["field", "value", "record_count", "row_refs"]

    if df.empty:
        return pd.DataFrame(columns=columns)

    rows = []

    for field in LINK_FIELDS:
        if field not in df.columns:
            continue

        values = df[field].astype("string").str.strip()
        valid = df[values.notna() & (values != "") & (values.str.lower() != "nan")]

        for value, group in valid.groupby(field, dropna=True):
            if len(group) > 1:
                refs = group.get(
                    "row_ref",
                    pd.Series(group.index.astype(str), index=group.index),
                )

                rows.append({
                    "field": field,
                    "value": str(value),
                    "record_count": len(group),
                    "row_refs": ", ".join(refs.astype(str).tolist()),
                })

    return pd.DataFrame(rows, columns=columns)


def detect_network_alerts(df):
    """Create explainable review alerts from E15 network-flow records."""
    columns = [
        "timestamp", "severity", "alert_type", "reason",
        "evidence_id", "row_ref", "source_ip", "request_id", "vendor_id",
    ]

    if df.empty:
        return pd.DataFrame(columns=columns)

    required = {"source_ip", "dst_system"}
    if not required.issubset(df.columns):
        return pd.DataFrame(columns=columns)

    data = df.copy()

    # Only evaluate network-flow records.
    if "evidence_id" in data.columns:
        data = data[
            data["evidence_id"].astype(str).str.upper().eq("E15")
        ].copy()

    if data.empty:
        return pd.DataFrame(columns=columns)

    data["source_ip"] = data["source_ip"].fillna("").astype(str).str.strip()
    data["dst_system"] = data["dst_system"].fillna("").astype(str)
    data["_destination"] = data["dst_system"].str.lower()

    data["_host_match"] = (
        data["source_ip"].eq(SUSPICIOUS_HOST_IP)
    )

    if "src_label" in data.columns:
        data["_host_match"] |= (
            data["src_label"].fillna("").astype(str).str.lower()
            .eq(SUSPICIOUS_HOST_LABEL)
        )

    data["_sensitive_destination"] = data["_destination"].apply(
        lambda value: any(term in value for term in SENSITIVE_DESTINATIONS)
    )

    data["_timestamp"] = pd.to_datetime(
        data.get("timestamp"), errors="coerce", utc=True
    )

    data["_bytes_out"] = pd.to_numeric(
        data.get("bytes_out", pd.Series(0, index=data.index)),
        errors="coerce",
    ).fillna(0)

    data["_bytes_in"] = pd.to_numeric(
        data.get("bytes_in", pd.Series(0, index=data.index)),
        errors="coerce",
    ).fillna(0)

    data["_total_bytes"] = data["_bytes_out"] + data["_bytes_in"]

    alerts = []

    # Rule 1: suspicious build host connecting to finance/support systems.
    host_flows = data[
        data["_host_match"] & data["_sensitive_destination"]
    ].copy()

    if not host_flows.empty:
        host_flows["_date"] = host_flows["_timestamp"].dt.strftime("%Y-%m-%d")

        for date, group in host_flows.groupby("_date", dropna=False):
            refs = group.get(
                "row_ref",
                pd.Series(group.index.astype(str), index=group.index),
            )

            alerts.append({
                "timestamp": group["_timestamp"].min(),
                "severity": "Medium",
                "alert_type": "Unusual build-host access to sensitive systems",
                "reason": (
                    f"{SUSPICIOUS_HOST_LABEL} ({SUSPICIOUS_HOST_IP}) made "
                    f"{len(group)} network connection(s) to "
                    f"{', '.join(sorted(group['dst_system'].dropna().astype(str).unique()))} "
                    f"on {date}. Confirm whether this access was authorised."
                ),
                "evidence_id": "E15",
                "row_ref": ", ".join(refs.astype(str).tolist()),
                "source_ip": SUSPICIOUS_HOST_IP,
                "request_id": None,
                "vendor_id": None,
            })

    # Rule 2: individual network flows exceeding the review threshold.
    large_flows = data[data["_total_bytes"] >= LARGE_TRANSFER_BYTES]

    for _, row in large_flows.iterrows():
        alerts.append({
            "timestamp": row.get("_timestamp"),
            "severity": "Medium",
            "alert_type": "Large network transfer requires review",
            "reason": (
                f"Network flow transferred {int(row['_total_bytes']):,} "
                f"combined bytes (bytes_out + bytes_in) between "
                f"{row.get('source_ip')} and {row.get('dst_system')}. "
                "Confirm transfer direction, purpose and authorisation."
            ),
            "evidence_id": row.get("evidence_id", "E15"),
            "row_ref": row.get("row_ref"),
            "source_ip": row.get("source_ip"),
            "request_id": row.get("request_id"),
            "vendor_id": row.get("vendor_id"),
        })

    # Rule 3: build-host access outside the usual 01:00–03:00 UTC sync window.
    timed_host_flows = host_flows[
        host_flows["_timestamp"].notna()
    ].copy()

    if not timed_host_flows.empty:
        timed_host_flows["_hour"] = timed_host_flows["_timestamp"].dt.hour

        outside_window = timed_host_flows[
            (timed_host_flows["_hour"] < NORMAL_SYNC_START_HOUR)
            | (timed_host_flows["_hour"] >= NORMAL_SYNC_END_HOUR)
        ]

        if not outside_window.empty:
            outside_window["_date"] = (
                outside_window["_timestamp"].dt.strftime("%Y-%m-%d")
            )

            for date, group in outside_window.groupby("_date"):
                refs = group.get(
                    "row_ref",
                    pd.Series(group.index.astype(str), index=group.index),
                )

                alerts.append({
                    "timestamp": group["_timestamp"].min(),
                    "severity": "Medium",
                    "alert_type": "Network activity outside usual sync window",
                    "reason": (
                        f"{len(group)} connection(s) from {SUSPICIOUS_HOST_IP} "
                        f"to sensitive systems occurred outside the "
                        "01:00–03:00 UTC review window on "
                        f"{date}. Confirm the approved maintenance schedule."
                    ),
                    "evidence_id": "E15",
                    "row_ref": ", ".join(refs.astype(str).tolist()),
                    "source_ip": SUSPICIOUS_HOST_IP,
                    "request_id": None,
                    "vendor_id": None,
                })

    return pd.DataFrame(alerts, columns=columns)


def build_timeline(df):
    """Return evidence records in timestamp order."""
    if df.empty:
        return df.copy()

    result = df.copy()

    if "timestamp" in result.columns:
        result = result.sort_values("timestamp", na_position="last")

    preferred = [
        "timestamp", "evidence_id", "row_ref", "source_file",
        "event_type", "action", "method", "endpoint",
        "source_ip", "src_label", "dst_system", "dst_port",
        "bytes_out", "bytes_in", "result",
        "api_key", "request_id", "vendor_id",
    ]

    selected = [column for column in preferred if column in result.columns]
    return result[selected] if selected else result